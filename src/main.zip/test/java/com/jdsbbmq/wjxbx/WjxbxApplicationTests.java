package com.jdsbbmq.wjxbx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WjxbxApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void MainTest() {
        WjxbxApplication.main(new String[]{}); // just for test coverage
    }

}
