onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  handleHeaderLoad()
  fetchProjectList()
}

let projectList = []

const fetchProjectList = () => {
  console.log($util.getItem('userInfo').id)
  $.ajax({
    url: API_BASE_URL + '/selectAllProject',
    type: "POST",
    data: $util.getItem('userInfo').id,
    dataType: "json",
    contentType: "application/json",
    success(res) {
      projectList = res
      $('#content').html('')
      res.map(item => {
        $('#content').append(`
          <div class="list">
            <div class="list-header">
              <div>${item.projectName}</div>
              <div>
                <button type="button" class="btn btn-link" onclick="onCreateQuestionnaire()">创建问卷</button>
                <button type="button" class="btn btn-link" onclick="onSeeProject('${item.id}')">查看</button>
                <button type="button" class="btn btn-link" onclick="onEditProject('${item.id}')">编辑</button>
                <button type="button" class="btn btn-link" onclick="onDelProject('${item.id}')">删除</button>
              </div>
            </div>
            <div class="list-footer">
              <div>暂无调查问卷或问卷已过期</div>
            </div>
          </div>
        `)
      })
    }
  })
}

const queryList=()=>{
    let projectName=document.getElementById("projectName").value;
    if(projectName){
        $.ajax({
        url: API_BASE_URL + '/selectProjectByName',
        type: "POST",
        data: projectName,
        dataType: "json",
        contentType: "application/json",
        success(res) {
            projectList = res
            $('#content').html('')
            res.map(item => {
            $('#content').append(`
                <div class="list">
                <div class="list-header">
                    <div>${item.projectName}</div>
                    <div>
                    <button type="button" class="btn btn-link" onclick="onCreateQuestionnaire()">创建问卷</button>
                    <button type="button" class="btn btn-link" onclick="onSeeProject('${item.id}')">查看</button>
                    <button type="button" class="btn btn-link" onclick="onEditProject('${item.id}')">编辑</button>
                    <button type="button" class="btn btn-link" onclick="onDelProject('${item.id}')">删除</button>
                    </div>
                </div>
                <div class="list-footer">
                    <div>暂无调查问卷或问卷已过期</div>
                </div>
                </div>
            `)
            })
        }
        })
    }else{
        fetchProjectList()
    }
}

const onCreatePrject = () => {
  location.href = "../createProject/index.html"
}

const onCreateQuestionnaire = () => {
  location.href = "../createQuestionnaire/index.html"
}

const onSeeProject = (id) => {
  $util.setPageParam('seeProject', id)
  location.href = "../seeProject/index.html"
}

const onEditProject = (id) => {
  let project = projectList.filter(item => item.id === id)[0]
  $util.setPageParam('editProject', project)
  location.href = "../editProject/index.html"
}

const onDelProject = (pid) => {
  let state = confirm("确认删除该项目吗？")

  if (state) {
    //alert(JSON.stringify(params))
    $.ajax({
      url: API_BASE_URL + '/deleteProject',
      type: "POST",
      data: pid,
      dataType: "json",
      contentType: "application/json",
      success() {
        alert("删除成功")
        fetchProjectList()
      }
    })
  }

}
