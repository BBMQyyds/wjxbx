let project = {}

onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  $('#headerDivB').text('编辑项目')

  project = $util.getPageParam('editProject')

  $('#projectName').val(project.projectName)
  $('#projectDescribe').val(project.projectContent)
}

const handleSaveChange = () => {
  let params = {
    id: project.id,
    userId: project.userId,
    projectName: $('#projectName').val(),
    projectContent: $('#projectDescribe').val(),
    createdBy: $util.getItem('userInfo').createdBy,
    creationDate: $util.getItem('userInfo').creationDate,
    lastUpdateBy: $util.getItem('userInfo').lastUpdateBy,
    lastUpdateDate: $util.getItem('userInfo').lastUpdateDate
  }
  if (!params.projectName) return alert('项目名称不能为空！')
  if (!params.projectContent) return alert('项目描述不能为空！')
  $.ajax({
    url: API_BASE_URL + '/updateProject',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success() {
      alert("修改成功")
      location.href = "../questionnaire/index.html"
    }
  })
}
