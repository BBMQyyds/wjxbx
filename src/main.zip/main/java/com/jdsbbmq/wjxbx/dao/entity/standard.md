# entity规范说明

## 命名规范

### 数据库表名以大写字母开头 + Entity，驼峰命名，如：UserEntity

## 属性规范

### 属性名以小写字母开头，驼峰命名，如：startTime

### 属性名（驼峰）与数据库字段名（下划线）一致，如：startTime->start_time