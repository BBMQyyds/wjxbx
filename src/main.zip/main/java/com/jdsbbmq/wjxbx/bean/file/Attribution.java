package com.jdsbbmq.wjxbx.bean.file;

public class Attribution {
    private String parentId;
    private String childId;

    //Type有project,file,questionnaire(待定）
    private String childType;
}
